# Coconut Ladoo

**Parslia Kitchen OS** · RECIPE CARD

Pure Prasad · No onion · No garlic · No eggs · No meat · No fish

Printed: 26 August 2026

**Sweet Manipur**

Quick coconut balls with jaggery.

| YIELD | PORTION | SERVICE | TIME |
|---|---|---|---|
| 4 portions | 1 portion | Hot | Prep 5 min · Cook 10 min |

**Tags:** Vegetarian, No onion, No garlic, No eggs, No meat, No fish, Gluten Free*

**Kitchen:** Manipur — Meitei vegetarian table

**Cookware:** Stainless steel kadhai or saucepan — never aluminium

**Diet:** Vegetarian · no onion · no garlic · no allium · no aluminium

## Ingredients *(for 4 portions)*

| Qty | Unit | Approx | Ingredient |
|-----|------|--------|------------|
| 200 | g | — | fresh grated coconut |
| 120 | g | — | jaggery, grated |
| 4 | pods | ≈ 2 g | green cardamom, powdered |
| 1 | tsp | ≈ 2.5 g | ghee, for the pan |

## Method

1. Mise en place. Weigh every ingredient on this card for 4 portions. Set Stainless steel kadhai or saucepan — never aluminium. Wash produce. Confirm spice blends have no onion or garlic powder. No onion, no garlic, no aluminium.
2. Cut vegetables to even size so they cook together.
3. Cook coconut and jaggery in a steel pan 6–8 minutes until the mix holds together.
4. Add cardamom. Work in Stainless steel kadhai or saucepan — never aluminium. Cook to the doneness below, tasting salt at the end. Do not add onion, garlic or aluminium cookware.
5. Shape 12 ladoos. Work in Stainless steel kadhai or saucepan — never aluminium. Cook to the doneness below, tasting salt at the end. Do not add onion, garlic or aluminium cookware.
6. Cool. Work in Stainless steel kadhai or saucepan — never aluminium. Cook to the doneness below, tasting salt at the end. Do not add onion, garlic or aluminium cookware.
7. Doneness: mixture leaves the sides of the pan, or milk is thick enough to coat a spoon, or syrup has taken the stated string.
8. Taste and adjust salt, lemon or chilli only — do not add onion or garlic at the finish. Garnish as listed. Yield is 4 portions.
9. Hold as the dish is eaten — hot sweets in a bain of hot water, chilled sweets in the fridge. Label date and time. Service: Hot.

## Nutrition per portion

| kcal | Protein | Carbs | Fat | Fibre |
|---|---|---|---|---|
| 298 | 2 g | 37 g | 17 g | 5 g |

Nutrition is a kitchen estimate from typical produce values, not a laboratory analysis.

## Allergens

- Milk
- Always verify labels; this card is a kitchen estimate, not a lab certificate.

## Chef notes

For Coconut Ladoo: keep the mix slightly drier than you think; wet mixes split or go greasy. Bloom hing in hot fat 20–30 seconds; raw hing tastes medicinal. Commercial hing is often cut with wheat flour — use a gluten-free hing if you must mark Gluten Free. Never cook tomato, tamarind, lemon, yogurt or milk in aluminium; use stainless steel, iron, clay or glass. Spice blends: read the packet. Many garam masalas hide onion or garlic powder.

## Service notes

Cut even portions. Garnish with nuts only if the allergen card allows. Service temperature: Hot. Allergen label for this dish: Milk; Always verify labels; this card is a kitchen estimate, not a lab certificate. State clearly: vegetarian, no onion, no garlic, no eggs, no meat, no fish. Nutrition on this card is an estimate for 1 portion of 4.
