# Soft Roti

**Parslia Kitchen OS** · RECIPE CARD

Pure Prasad · No onion · No garlic · No eggs · No meat · No fish

Printed: 26 August 2026

**Bread Manipur**

Plain wheat roti for guests who want a North-Indian bread with the stew.

| YIELD | PORTION | SERVICE | TIME |
|---|---|---|---|
| 4 portions | 1 portion | Hot | Prep 15 min · Cook 15 min |

**Tags:** Vegetarian, No onion, No garlic, No eggs, No meat, No fish, Contains gluten

**Kitchen:** Manipur — Meitei vegetarian table

**Cookware:** Cast-iron tawa (not aluminium)

**Diet:** Vegetarian · no onion · no garlic · no allium · no aluminium

## Ingredients *(for 4 portions)*

| Qty | Unit | Approx | Ingredient |
|-----|------|--------|------------|
| 300 | g | — | whole-wheat atta |
| 180 | ml | — | water, or as needed |
| ½ | tsp | ≈ 3 g | salt |
| 1 | tsp | ≈ 2.5 g | ghee, for finishing |

## Method

1. Mise en place. Weigh every ingredient on this card for 4 portions. Set Cast-iron tawa (not aluminium). Wash produce. Confirm spice blends have no onion or garlic powder. No onion, no garlic, no aluminium.
2. Cut vegetables to even size so they cook together. For dough, add water gradually; rest covered 10–15 minutes before rolling.
3. Heat fat in Cast-iron tawa (not aluminium) on medium. Bloom hing 20–30 seconds until fragrant — this is the onion-garlic stand-in. Do not burn it.
4. Knead atta, salt and water 5 minutes. Work in Cast-iron tawa (not aluminium). Cook to the doneness below, tasting salt at the end. Do not add onion, garlic or aluminium cookware.
5. Rest 10 minutes. Work in Cast-iron tawa (not aluminium). Cook to the doneness below, tasting salt at the end. Do not add onion, garlic or aluminium cookware.
6. Divide into 8 balls. Work in Cast-iron tawa (not aluminium). Cook to the doneness below, tasting salt at the end. Do not add onion, garlic or aluminium cookware.
7. Roll 15 cm discs. Work in Cast-iron tawa (not aluminium). Cook to the doneness below, tasting salt at the end. Do not add onion, garlic or aluminium cookware.
8. Cook on a cast-iron tawa until they puff. Work in Cast-iron tawa (not aluminium). Cook to the doneness below, tasting salt at the end. Do not add onion, garlic or aluminium cookware.
9. Brush with ghee. Work in Cast-iron tawa (not aluminium). Cook to the doneness below, tasting salt at the end. Do not add onion, garlic or aluminium cookware.
10. Keep wrapped in a cloth. Work in Cast-iron tawa (not aluminium). Cook to the doneness below, tasting salt at the end. Do not add onion, garlic or aluminium cookware.
11. Doneness: bread is cooked through, no wet dough in the centre, light brown spots on the face.
12. Taste and adjust salt, lemon or chilli only — do not add onion or garlic at the finish. Garnish as listed. Yield is 4 portions.
13. Hold wrapped in a clean cloth in a covered steel box up to 30 minutes. Refresh on a hot tawa 20 seconds if needed. Service: Hot.

## Nutrition per portion

| kcal | Protein | Carbs | Fat | Fibre |
|---|---|---|---|---|
| 261 | 9 g | 54 g | 2 g | 8 g |

Nutrition is a kitchen estimate from typical produce values, not a laboratory analysis.

## Allergens

- Gluten (wheat)
- Milk
- Always verify labels; this card is a kitchen estimate, not a lab certificate.

## Chef notes

For Soft Roti: keep the mix slightly drier than you think; wet mixes split or go greasy. Bloom hing in hot fat 20–30 seconds; raw hing tastes medicinal. Commercial hing is often cut with wheat flour — use a gluten-free hing if you must mark Gluten Free. Never cook tomato, tamarind, lemon, yogurt or milk in aluminium; use stainless steel, iron, clay or glass. Spice blends: read the packet. Many garam masalas hide onion or garlic powder.

## Service notes

Send to table wrapped. Do not stack in plastic or they sweat. Service temperature: Hot. Allergen label for this dish: Gluten (wheat); Milk; Always verify labels; this card is a kitchen estimate, not a lab certificate. State clearly: vegetarian, no onion, no garlic, no eggs, no meat, no fish. Nutrition on this card is an estimate for 1 portion of 4.
