# Naan (tandoor, no garlic)

**Parslia Kitchen OS** · RECIPE CARD

Pure Prasad · No onion · No garlic · No eggs · No meat · No fish

Printed: 26 August 2026

**Bread Pan-India**

Signature bread from Pan India, cooked without onion or garlic.

| YIELD | PORTION | SERVICE | TIME |
|---|---|---|---|
| 4 portions | 1 portion | Hot | Prep 30 min · Cook 15 min |

**Tags:** Vegetarian, No onion, No garlic, No eggs, No meat, No fish, Contains gluten

**Kitchen:** Pan-India — Dishes cooked in homes all over India

**Cookware:** Stainless steel or clay pot — never aluminium

**Diet:** Vegetarian · no onion · no garlic · no allium · no aluminium

## Ingredients *(for 4 portions)*

| Qty | Unit | Approx | Ingredient |
|-----|------|--------|------------|
| 250 | g | — | maida (refined flour) |

## Method

1. Mise en place. Mix maida, yogurt, baking powder, salt and a little ghee. No garlic, no garlic butter. Rest 30 minutes. Clay tandoor or very hot steel tray.
2. Divide. Roll teardrops 4 mm thick. Wet the back face if sticking to a tandoor wall.
3. Bake until puffed with charred blisters, 60–90 seconds. Brush with plain ghee only.
4. Doneness: cooked through, blistered, soft. Serve at once.
5. Hold 10 minutes in a cloth. Label gluten and milk.

## Nutrition per portion

| kcal | Protein | Carbs | Fat | Fibre |
|---|---|---|---|---|
| 228 | 6 g | 48 g | 1 g | 2 g |

Nutrition is a kitchen estimate from typical produce values, not a laboratory analysis.

## Allergens

- Gluten (wheat)
- Milk
- Always verify labels; this card is a kitchen estimate, not a lab certificate.

## Chef notes

For Naan (tandoor, no garlic): keep the mix slightly drier than you think; wet mixes split or go greasy. Bloom hing in hot fat 20–30 seconds; raw hing tastes medicinal. Commercial hing is often cut with wheat flour — use a gluten-free hing if you must mark Gluten Free. Never cook tomato, tamarind, lemon, yogurt or milk in aluminium; use stainless steel, iron, clay or glass. Spice blends: read the packet. Many garam masalas hide onion or garlic powder.

## Service notes

Send to table wrapped. Do not stack in plastic or they sweat. Service temperature: Hot. Allergen label for this dish: Gluten (wheat); Milk; Always verify labels; this card is a kitchen estimate, not a lab certificate. State clearly: vegetarian, no onion, no garlic, no eggs, no meat, no fish. Nutrition on this card is an estimate for 1 portion of 4.
