# Gongura Pappu

**Parslia Kitchen OS** · RECIPE CARD

Pure Prasad · No onion · No garlic · No eggs · No meat · No fish

Printed: 26 August 2026

**Main Andhra Pradesh**

Sorrel dal — Andhra’s sour signature.

| YIELD | PORTION | SERVICE | TIME |
|---|---|---|---|
| 4 portions | 1 portion | Hot | Prep 10 min · Cook 30 min |

**Tags:** Vegetarian, No onion, No garlic, No eggs, No meat, No fish, Vegan, Contains gluten, Mustard

**Kitchen:** Andhra Pradesh — Andhra vegetarian / temple pappu

**Cookware:** Stainless steel or clay pot — never aluminium

**Diet:** Vegetarian · no onion · no garlic · no allium · no aluminium

## Ingredients *(for 4 portions)*

| Qty | Unit | Approx | Ingredient |
|-----|------|--------|------------|
| 150 | g | — | toor dal, rinsed |
| 150 | g | — | gongura leaves |
| 1 | tsp | ≈ 2.5 g | mustard seeds |
| 1 | tsp | ≈ 2.5 g | cumin seeds |
| ½ | tsp | ≈ 1.2 g | hing (asafoetida) |
| 2 | pieces | ≈ 16 g | dry red chillies |
| 10 | leaves | ≈ 5 g | fresh curry leaves |
| 1 | tsp | ≈ 6 g | salt, or to taste |

## Method

1. Mise en place. Weigh every ingredient on this card for 4 portions. Set Stainless steel or clay pot — never aluminium. Wash produce. Confirm spice blends have no onion or garlic powder. No onion, no garlic, no aluminium.
2. Cut vegetables to even size so they cook together.
3. Heat fat in Stainless steel or clay pot — never aluminium on medium. Bloom hing 20–30 seconds until fragrant — this is the onion-garlic stand-in. Do not burn it.
4. Cook dal. Work in Stainless steel or clay pot — never aluminium. Cook to the doneness below, tasting salt at the end. Do not add onion, garlic or aluminium cookware.
5. Wilt gongura in tadka. Work in Stainless steel or clay pot — never aluminium. Cook to the doneness below, tasting salt at the end. Do not add onion, garlic or aluminium cookware.
6. Mix. Work in Stainless steel or clay pot — never aluminium. Cook to the doneness below, tasting salt at the end. Do not add onion, garlic or aluminium cookware.
7. No onion. Work in Stainless steel or clay pot — never aluminium. Cook to the doneness below, tasting salt at the end. Do not add onion, garlic or aluminium cookware.
8. Doneness: vegetables yield to a knife, gravy coats a spoon, salt is balanced. Rest 2 minutes off the heat so seasoning settles.
9. Taste and adjust salt, lemon or chilli only — do not add onion or garlic at the finish. Garnish as listed. Yield is 4 portions.
10. Hold hot above 63 C if the pass is delayed, or cool quickly and reheat once only to piping hot. Do not hold in aluminium. Service: Hot.

## Nutrition per portion

| kcal | Protein | Carbs | Fat | Fibre |
|---|---|---|---|---|
| 179 | 10 g | 31 g | 2 g | 7 g |

Nutrition is a kitchen estimate from typical produce values, not a laboratory analysis.

## Allergens

- Gluten (wheat)
- Mustard
- Always verify labels; this card is a kitchen estimate, not a lab certificate.

## Chef notes

For Gongura Pappu: keep the mix slightly drier than you think; wet mixes split or go greasy. Bloom hing in hot fat 20–30 seconds; raw hing tastes medicinal. Commercial hing is often cut with wheat flour — use a gluten-free hing if you must mark Gluten Free. Never cook tomato, tamarind, lemon, yogurt or milk in aluminium; use stainless steel, iron, clay or glass. Spice blends: read the packet. Many garam masalas hide onion or garlic powder.

## Service notes

Plate with bread or rice from the same kitchen card. Sauce should nap, not flood. Service temperature: Hot. Allergen label for this dish: Gluten (wheat); Mustard; Always verify labels; this card is a kitchen estimate, not a lab certificate. State clearly: vegetarian, no onion, no garlic, no eggs, no meat, no fish. Nutrition on this card is an estimate for 1 portion of 4.
