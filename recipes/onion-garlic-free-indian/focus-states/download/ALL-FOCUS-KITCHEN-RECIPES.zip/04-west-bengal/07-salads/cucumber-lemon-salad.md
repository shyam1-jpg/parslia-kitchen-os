# Cucumber Lemon Salad

**Recipe card** · West Bengal kitchen · Salad

| | |
|---|---|
| **Kitchen** | West Bengal — Bengali niramish (vegetarian, no onion garlic) |
| **Course** | Salad |
| **Serves** | 4 |
| **Prep** | 6 min |
| **Cook** | 0 min |
| **Total** | 6 min |
| **Cookware** | Steel or glass bowl |
| **Diet** | Vegetarian · no onion · no garlic · no allium · no aluminium |

Signature salad from West Bengal, cooked without onion or garlic.

## Ingredients *(for 4 servings)*

| Qty | Unit | Ingredient |
|-----|------|------------|
| 2 | pieces | cucumbers |
| 1 | tbsp | lemon juice |
| 2 | pieces | green chillies, slit |
| 1 | tsp | salt, or to taste |
| 15 | g | fresh coriander leaves |

## Method

1. Toss. No peyaj.
