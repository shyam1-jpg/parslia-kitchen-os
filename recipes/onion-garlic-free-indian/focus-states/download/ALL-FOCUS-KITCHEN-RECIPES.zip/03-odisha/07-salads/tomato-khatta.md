# Tomato Khatta

**Parslia Kitchen OS** · RECIPE CARD

Pure Prasad · No onion · No garlic · No eggs · No meat · No fish

Printed: 26 August 2026

**Salad Odisha**

Signature salad from Odisha, cooked without onion or garlic.

| YIELD | PORTION | SERVICE | TIME |
|---|---|---|---|
| 4 portions | 1 portion | Cold | Prep 10 min · Cook 10 min |

**Tags:** Vegetarian, No onion, No garlic, No eggs, No meat, No fish, Gluten Free*

**Kitchen:** Odisha — Odia temple and home kitchen

**Cookware:** Stainless steel kadhai or saucepan — never aluminium

**Diet:** Vegetarian · no onion · no garlic · no allium · no aluminium

## Ingredients *(for 4 portions)*

| Qty | Unit | Approx | Ingredient |
|-----|------|--------|------------|
| 2 | pieces | ≈ 200 g | ripe tomatoes, chopped |
| 1 | tsp | ≈ 2.5 g | panch phoron |
| 100 | g | — | jaggery, grated |
| 2 | pieces | ≈ 16 g | green or dry red chillies |
| 1 | tsp | ≈ 6 g | salt, or to taste |

## Method

1. Mise en place. Weigh every ingredient on this card for 4 portions. Set Stainless steel kadhai or saucepan — never aluminium. Wash produce. Confirm spice blends have no onion or garlic powder. No onion, no garlic, no aluminium.
2. Cut vegetables to even size so they cook together.
3. Cook to a relish. Work in Stainless steel kadhai or saucepan — never aluminium. Cook to the doneness below, tasting salt at the end. Do not add onion, garlic or aluminium cookware.
4. Doneness: vegetables stay crisp; dressing coats evenly; seasoning is bright, not flat.
5. Taste and adjust salt, lemon or chilli only — do not add onion or garlic at the finish. Garnish as listed. Yield is 4 portions.
6. Hold chilled, covered, up to 2 hours. Stir before service. Discard if it weeps heavily or smells sour beyond yogurt character. Service: Cold.

## Nutrition per portion

| kcal | Protein | Carbs | Fat | Fibre |
|---|---|---|---|---|
| 107 | 1 g | 27 g | 0 g | 1 g |

Nutrition is a kitchen estimate from typical produce values, not a laboratory analysis.

## Allergens

- Milk
- Always verify labels; this card is a kitchen estimate, not a lab certificate.

## Chef notes

For Tomato Khatta: squeeze wet vegetables dry or the bowl weeps on the pass. Season slightly higher than you think — cold dulls salt. No onion, no garlic, no allium garnish. Use steel or glass, never aluminium. Dress at the last minute. Verify dahi and spice labels.

## Service notes

Dress at the last minute. Toss at the pass, do not send a wet bowl. Service temperature: Cold. Allergen label for this dish: Milk; Always verify labels; this card is a kitchen estimate, not a lab certificate. State clearly: vegetarian, no onion, no garlic, no eggs, no meat, no fish. Nutrition on this card is an estimate for 1 portion of 4.
