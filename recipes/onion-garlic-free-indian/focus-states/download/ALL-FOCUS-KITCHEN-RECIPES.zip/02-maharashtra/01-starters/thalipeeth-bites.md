# Thalipeeth Bites

**Parslia Kitchen OS** · RECIPE CARD

Pure Prasad · No onion · No garlic · No eggs · No meat · No fish

Printed: 26 August 2026

**Starter Maharashtra**

Multi-grain savoury pancake. Skip onion; use sesame, chilli, coriander.

| YIELD | PORTION | SERVICE | TIME |
|---|---|---|---|
| 4 portions | 1 portion | Hot | Prep 15 min · Cook 15 min |

**Tags:** Vegetarian, No onion, No garlic, No eggs, No meat, No fish, Vegan, Contains gluten, Sesame

**Kitchen:** Maharashtra — Maharashtrian vegetarian and vrat cooking

**Cookware:** Cast-iron tawa (not aluminium)

**Diet:** Vegetarian · no onion · no garlic · no allium · no aluminium

## Ingredients *(for 4 portions)*

| Qty | Unit | Approx | Ingredient |
|-----|------|--------|------------|
| 1 | cup | ≈ 120 g | jowar-bajra-atta mix (bhajani) |
| 3 | tbsp | ≈ 24 g | white sesame seeds |
| 1 | tbsp | ≈ 8 g | ginger-green chilli paste (no garlic) |
| 15 | g | — | fresh coriander leaves |
| 1 | tsp | ≈ 6 g | salt, or to taste |
| 2 | tbsp | ≈ 28 g | oil |

## Method

1. Mise en place. Weigh every ingredient on this card for 4 portions. Set Cast-iron tawa (not aluminium). Wash produce. Confirm spice blends have no onion or garlic powder. No onion, no garlic, no aluminium.
2. Cut vegetables to even size so they cook together. For dough, add water gradually; rest covered 10–15 minutes before rolling.
3. Pat small rounds on iron tawa. Work in Cast-iron tawa (not aluminium). Cook to the doneness below, tasting salt at the end. Do not add onion, garlic or aluminium cookware.
4. Cook both sides. Work in Cast-iron tawa (not aluminium). Cook to the doneness below, tasting salt at the end. Do not add onion, garlic or aluminium cookware.
5. Doneness: crust or crumb is set, centre is hot, no raw flour or potato taste. Drain on a steel rack, not paper in the fryer basket.
6. Taste and adjust salt, lemon or chilli only — do not add onion or garlic at the finish. Garnish as listed. Yield is 4 portions.
7. Hold hot above 63 C if the pass is delayed, or cool quickly and reheat once only to piping hot. Do not hold in aluminium. Service: Hot.

## Nutrition per portion

| kcal | Protein | Carbs | Fat | Fibre |
|---|---|---|---|---|
| 211 | 5 g | 23 g | 12 g | 4 g |

Nutrition is a kitchen estimate from typical produce values, not a laboratory analysis.

## Allergens

- Gluten (wheat)
- Sesame
- Always verify labels; this card is a kitchen estimate, not a lab certificate.

## Chef notes

For Thalipeeth Bites: keep the mix slightly drier than you think; wet mixes split or go greasy. Bloom hing in hot fat 20–30 seconds; raw hing tastes medicinal. Commercial hing is often cut with wheat flour — use a gluten-free hing if you must mark Gluten Free. Never cook tomato, tamarind, lemon, yogurt or milk in aluminium; use stainless steel, iron, clay or glass. Spice blends: read the packet. Many garam masalas hide onion or garlic powder.

## Service notes

Serve immediately while crisp or hot. Offer a chutney or raita that is also onion-garlic free. Service temperature: Hot. Allergen label for this dish: Gluten (wheat); Sesame; Always verify labels; this card is a kitchen estimate, not a lab certificate. State clearly: vegetarian, no onion, no garlic, no eggs, no meat, no fish. Nutrition on this card is an estimate for 1 portion of 4.
