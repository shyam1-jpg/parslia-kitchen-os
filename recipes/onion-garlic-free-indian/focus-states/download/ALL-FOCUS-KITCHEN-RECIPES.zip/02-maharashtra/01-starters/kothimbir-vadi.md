# Kothimbir Vadi

**Parslia Kitchen OS** · RECIPE CARD

Pure Prasad · No onion · No garlic · No eggs · No meat · No fish

Printed: 26 August 2026

**Starter Maharashtra**

Coriander-besan steamed cake, sliced and fried.

| YIELD | PORTION | SERVICE | TIME |
|---|---|---|---|
| 4 portions | 1 portion | Hot | Prep 20 min · Cook 20 min |

**Tags:** Vegetarian, No onion, No garlic, No eggs, No meat, No fish, Vegan, Contains gluten, Sesame

**Kitchen:** Maharashtra — Maharashtrian vegetarian and vrat cooking

**Cookware:** Stainless steel steamer and steel thali — never aluminium

**Diet:** Vegetarian · no onion · no garlic · no allium · no aluminium

## Ingredients *(for 4 portions)*

| Qty | Unit | Approx | Ingredient |
|-----|------|--------|------------|
| 2 | cups | ≈ 300 g | coriander |
| 1 | cup | ≈ 120 g | besan |
| 1 | tbsp | ≈ 8 g | ginger-green chilli paste (no garlic) |
| ½ | tsp | ≈ 1.2 g | turmeric powder |
| 3 | tbsp | ≈ 24 g | white sesame seeds |
| ½ | tsp | ≈ 1.2 g | hing (asafoetida) |
| 1 | tsp | ≈ 6 g | salt, or to taste |

## Method

1. Mise en place. Weigh every ingredient on this card for 4 portions. Set Stainless steel steamer and steel thali — never aluminium. Wash produce. Confirm spice blends have no onion or garlic powder. No onion, no garlic, no aluminium.
2. Cut vegetables to even size so they cook together.
3. Heat fat in Stainless steel steamer and steel thali — never aluminium on medium. Bloom hing 20–30 seconds until fragrant — this is the onion-garlic stand-in. Do not burn it.
4. Steam 12 minutes, slice, pan-fry in steel until crisp. Work in Stainless steel steamer and steel thali — never aluminium. Cook to the doneness below, tasting salt at the end. Do not add onion, garlic or aluminium cookware.
5. Doneness: crust or crumb is set, centre is hot, no raw flour or potato taste. Drain on a steel rack, not paper in the fryer basket.
6. Taste and adjust salt, lemon or chilli only — do not add onion or garlic at the finish. Garnish as listed. Yield is 4 portions.
7. Hold hot above 63 C if the pass is delayed, or cool quickly and reheat once only to piping hot. Do not hold in aluminium. Service: Hot.

## Nutrition per portion

| kcal | Protein | Carbs | Fat | Fibre |
|---|---|---|---|---|
| 243 | 11 g | 33 g | 8 g | 6 g |

Nutrition is a kitchen estimate from typical produce values, not a laboratory analysis.

## Allergens

- Gluten (wheat)
- Sesame
- Always verify labels; this card is a kitchen estimate, not a lab certificate.

## Chef notes

For Kothimbir Vadi: keep the mix slightly drier than you think; wet mixes split or go greasy. Bloom hing in hot fat 20–30 seconds; raw hing tastes medicinal. Commercial hing is often cut with wheat flour — use a gluten-free hing if you must mark Gluten Free. Never cook tomato, tamarind, lemon, yogurt or milk in aluminium; use stainless steel, iron, clay or glass. Spice blends: read the packet. Many garam masalas hide onion or garlic powder. Cook or roast besan until the raw smell is gone.

## Service notes

Serve immediately while crisp or hot. Offer a chutney or raita that is also onion-garlic free. Service temperature: Hot. Allergen label for this dish: Gluten (wheat); Sesame; Always verify labels; this card is a kitchen estimate, not a lab certificate. State clearly: vegetarian, no onion, no garlic, no eggs, no meat, no fish. Nutrition on this card is an estimate for 1 portion of 4.
