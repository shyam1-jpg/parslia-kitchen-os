# Sharkara Upperi

**Parslia Kitchen OS** · RECIPE CARD

Pure Prasad · No onion · No garlic · No eggs · No meat · No fish

Printed: 26 August 2026

**Sweet Kerala**

Jaggery-coated banana chips.

| YIELD | PORTION | SERVICE | TIME |
|---|---|---|---|
| 4 portions | 1 portion | Hot | Prep 10 min · Cook 20 min |

**Tags:** Vegetarian, No onion, No garlic, No eggs, No meat, No fish, Gluten Free*

**Kitchen:** Kerala — Kerala sadya kitchen

**Cookware:** Stainless steel kadhai or saucepan — never aluminium

**Diet:** Vegetarian · no onion · no garlic · no allium · no aluminium

## Ingredients *(for 4 portions)*

| Qty | Unit | Approx | Ingredient |
|-----|------|--------|------------|
| 2 | pieces | ≈ 240 g | ripe bananas |
| 200 | ml | — | jaggery syrup |
| ½ | tsp | ≈ 1.2 g | dry ginger powder |
| 4 | pods | ≈ 2 g | green cardamom, crushed |

## Method

1. Mise en place. Weigh every ingredient on this card for 4 portions. Set Stainless steel kadhai or saucepan — never aluminium. Wash produce. Confirm spice blends have no onion or garlic powder. No onion, no garlic, no aluminium.
2. Cut vegetables to even size so they cook together.
3. Toss chips in thick jaggery syrup in steel. Work in Stainless steel kadhai or saucepan — never aluminium. Cook to the doneness below, tasting salt at the end. Do not add onion, garlic or aluminium cookware.
4. Doneness: mixture leaves the sides of the pan, or milk is thick enough to coat a spoon, or syrup has taken the stated string.
5. Taste and adjust salt, lemon or chilli only — do not add onion or garlic at the finish. Garnish as listed. Yield is 4 portions.
6. Hold as the dish is eaten — hot sweets in a bain of hot water, chilled sweets in the fridge. Label date and time. Service: Hot.

## Nutrition per portion

| kcal | Protein | Carbs | Fat | Fibre |
|---|---|---|---|---|
| 246 | 1 g | 63 g | 0 g | 2 g |

Nutrition is a kitchen estimate from typical produce values, not a laboratory analysis.

## Allergens

- Milk
- Always verify labels; this card is a kitchen estimate, not a lab certificate.

## Chef notes

For Sharkara Upperi: keep the mix slightly drier than you think; wet mixes split or go greasy. Bloom hing in hot fat 20–30 seconds; raw hing tastes medicinal. Commercial hing is often cut with wheat flour — use a gluten-free hing if you must mark Gluten Free. Never cook tomato, tamarind, lemon, yogurt or milk in aluminium; use stainless steel, iron, clay or glass. Spice blends: read the packet. Many garam masalas hide onion or garlic powder.

## Service notes

Cut even portions. Garnish with nuts only if the allergen card allows. Service temperature: Hot. Allergen label for this dish: Milk; Always verify labels; this card is a kitchen estimate, not a lab certificate. State clearly: vegetarian, no onion, no garlic, no eggs, no meat, no fish. Nutrition on this card is an estimate for 1 portion of 4.
